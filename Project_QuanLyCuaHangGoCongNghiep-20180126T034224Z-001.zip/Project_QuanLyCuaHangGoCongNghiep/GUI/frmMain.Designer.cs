﻿namespace GUI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.ribbonControl_ButtonFunction = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem_KhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_DonHang = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_NhaCungCap = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_NhapHang = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_ThongTinTaiKhoan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_DoiMatKhau = new DevExpress.XtraBars.BarButtonItem();
            this.barHeaderItem1 = new DevExpress.XtraBars.BarHeaderItem();
            this.barButtonItem_DangXuat = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem_NhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup_Admin = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl_ButtonFunction)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl_ButtonFunction
            // 
            this.ribbonControl_ButtonFunction.ExpandCollapseItem.Id = 0;
            this.ribbonControl_ButtonFunction.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl_ButtonFunction.ExpandCollapseItem,
            this.barButtonItem_KhachHang,
            this.barButtonItem_DonHang,
            this.barButtonItem_NhaCungCap,
            this.barButtonItem_NhapHang,
            this.barButtonItem_ThongTinTaiKhoan,
            this.barButtonItem_DoiMatKhau,
            this.barHeaderItem1,
            this.barButtonItem_DangXuat,
            this.barButtonItem_NhanVien});
            this.ribbonControl_ButtonFunction.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl_ButtonFunction.MaxItemId = 14;
            this.ribbonControl_ButtonFunction.Name = "ribbonControl_ButtonFunction";
            this.ribbonControl_ButtonFunction.PageHeaderItemLinks.Add(this.barHeaderItem1);
            this.ribbonControl_ButtonFunction.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2});
            this.ribbonControl_ButtonFunction.Size = new System.Drawing.Size(808, 135);
            this.ribbonControl_ButtonFunction.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // barButtonItem_KhachHang
            // 
            this.barButtonItem_KhachHang.Caption = "Khách hàng";
            this.barButtonItem_KhachHang.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_KhachHang.Glyph")));
            this.barButtonItem_KhachHang.Id = 1;
            this.barButtonItem_KhachHang.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_KhachHang.LargeGlyph")));
            this.barButtonItem_KhachHang.Name = "barButtonItem_KhachHang";
            this.barButtonItem_KhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_KhachHang_ItemClick);
            // 
            // barButtonItem_DonHang
            // 
            this.barButtonItem_DonHang.Caption = "Đơn hàng";
            this.barButtonItem_DonHang.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DonHang.Glyph")));
            this.barButtonItem_DonHang.Id = 2;
            this.barButtonItem_DonHang.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DonHang.LargeGlyph")));
            this.barButtonItem_DonHang.Name = "barButtonItem_DonHang";
            // 
            // barButtonItem_NhaCungCap
            // 
            this.barButtonItem_NhaCungCap.Caption = "Nhà cung cấp";
            this.barButtonItem_NhaCungCap.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhaCungCap.Glyph")));
            this.barButtonItem_NhaCungCap.Id = 3;
            this.barButtonItem_NhaCungCap.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhaCungCap.LargeGlyph")));
            this.barButtonItem_NhaCungCap.Name = "barButtonItem_NhaCungCap";
            // 
            // barButtonItem_NhapHang
            // 
            this.barButtonItem_NhapHang.Caption = "Nhập hàng";
            this.barButtonItem_NhapHang.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhapHang.Glyph")));
            this.barButtonItem_NhapHang.Id = 4;
            this.barButtonItem_NhapHang.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhapHang.LargeGlyph")));
            this.barButtonItem_NhapHang.Name = "barButtonItem_NhapHang";
            // 
            // barButtonItem_ThongTinTaiKhoan
            // 
            this.barButtonItem_ThongTinTaiKhoan.Caption = "Thông tin tài khoản";
            this.barButtonItem_ThongTinTaiKhoan.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_ThongTinTaiKhoan.Glyph")));
            this.barButtonItem_ThongTinTaiKhoan.Id = 5;
            this.barButtonItem_ThongTinTaiKhoan.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_ThongTinTaiKhoan.LargeGlyph")));
            this.barButtonItem_ThongTinTaiKhoan.Name = "barButtonItem_ThongTinTaiKhoan";
            // 
            // barButtonItem_DoiMatKhau
            // 
            this.barButtonItem_DoiMatKhau.Caption = "Đổi mật khẩu";
            this.barButtonItem_DoiMatKhau.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DoiMatKhau.Glyph")));
            this.barButtonItem_DoiMatKhau.Id = 6;
            this.barButtonItem_DoiMatKhau.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DoiMatKhau.LargeGlyph")));
            this.barButtonItem_DoiMatKhau.Name = "barButtonItem_DoiMatKhau";
            // 
            // barHeaderItem1
            // 
            this.barHeaderItem1.Caption = "Tên tài khoản";
            this.barHeaderItem1.Id = 11;
            this.barHeaderItem1.Name = "barHeaderItem1";
            // 
            // barButtonItem_DangXuat
            // 
            this.barButtonItem_DangXuat.Caption = "Đăng xuất";
            this.barButtonItem_DangXuat.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DangXuat.Glyph")));
            this.barButtonItem_DangXuat.Id = 12;
            this.barButtonItem_DangXuat.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_DangXuat.LargeGlyph")));
            this.barButtonItem_DangXuat.Name = "barButtonItem_DangXuat";
            // 
            // barButtonItem_NhanVien
            // 
            this.barButtonItem_NhanVien.Caption = "Nhân viên";
            this.barButtonItem_NhanVien.Glyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhanVien.Glyph")));
            this.barButtonItem_NhanVien.Id = 13;
            this.barButtonItem_NhanVien.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("barButtonItem_NhanVien.LargeGlyph")));
            this.barButtonItem_NhanVien.Name = "barButtonItem_NhanVien";
            this.barButtonItem_NhanVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem_NhanVien_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.ribbonPage1.Appearance.Options.UseFont = true;
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup_Admin});
            this.ribbonPage1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage1.Image")));
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Quản Lý";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem_KhachHang);
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem_NhaCungCap);
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem_NhapHang);
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem_DonHang);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Dữ liệu";
            // 
            // ribbonPageGroup_Admin
            // 
            this.ribbonPageGroup_Admin.ItemLinks.Add(this.barButtonItem_NhanVien);
            this.ribbonPageGroup_Admin.Name = "ribbonPageGroup_Admin";
            this.ribbonPageGroup_Admin.Text = "Admin";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2});
            this.ribbonPage2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage2.Image")));
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Tài Khoản";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem_ThongTinTaiKhoan);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem_DoiMatKhau);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem_DangXuat);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayoutStore = System.Windows.Forms.ImageLayout.Stretch;
            this.BackgroundImageStore = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImageStore")));
            this.ClientSize = new System.Drawing.Size(808, 422);
            this.Controls.Add(this.ribbonControl_ButtonFunction);
            this.IsMdiContainer = true;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Cửa Hàng Kinh Doanh Ván Gỗ Công Nghiệp";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl_ButtonFunction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl_ButtonFunction;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_KhachHang;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_DonHang;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_NhaCungCap;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_NhapHang;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_ThongTinTaiKhoan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_DoiMatKhau;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_DangXuat;
        private DevExpress.XtraBars.BarButtonItem barButtonItem_NhanVien;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup_Admin;
    }
}