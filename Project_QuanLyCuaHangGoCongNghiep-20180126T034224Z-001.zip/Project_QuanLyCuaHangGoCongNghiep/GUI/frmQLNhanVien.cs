﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Configuration;
using System.Data.SqlClient;

namespace GUI
{
    public partial class frmQLNhanVien : DevExpress.XtraEditors.XtraForm
    {
        public frmQLNhanVien()
        {
            InitializeComponent();
            LoadListUser();
        }

        private void LoadListUser()
        {
            String constr = "Data Source=.\\SQLEXPRESS;Initial Catalog=QL_CuaHangGoCongNghiep;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constr);
            String query = "SELECT * FROM dbo.User";
            conn.Open();
            SqlCommand command = new SqlCommand(query, conn);
            DataTable data = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(data);
            conn.Close();
            dataGridView_NhanVien.DataSource = data;
        }
    }
}