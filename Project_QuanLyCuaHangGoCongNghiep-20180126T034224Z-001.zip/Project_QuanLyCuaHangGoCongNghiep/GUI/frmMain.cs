﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Skins.XtraForm;
using DevExpress.Utils;
using DevExpress.Skins;

namespace GUI
{
    public partial class frmMain : DevExpress.XtraEditors.XtraForm
    {
        public frmMain()
        {
            InitializeComponent();
            ribbonControl_ButtonFunction.Visible = false;
        }

        private void ShowForm(Form frm)
        {
            if (frm.Name != "frmMain" && frm.Name != "frmLogin")
            {
                frm.WindowState = FormWindowState.Maximized;
                frm.ControlBox = false;
                frm.MdiParent = this;
                frm.Show();
            }
            else if (frm.Name != "frmMain")
            {
                frm.MdiParent = this;
                frm.Show();
            }
        }

        protected override DevExpress.Skins.XtraForm.FormPainter CreateFormBorderPainter()
        {
            HorzAlignment formCaptionAlignment = HorzAlignment.Center;
            return new CustomFormPainter(this, LookAndFeel, formCaptionAlignment);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            frmLogin frm = new frmLogin();
            ShowForm(frm);
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát khỏi phần mềm?", "THÔNG BÁO", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void barButtonItem_KhachHang_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //frmQLKhachHang frm = new frmQLKhachHang();
            //ShowForm(frm);
        }

        private void barButtonItem_NhanVien_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmQLNhanVien frm = new frmQLNhanVien();
            ShowForm(frm);
        }
    }

    public class CustomFormPainter : FormPainter
    {
        public CustomFormPainter(Control owner, DevExpress.Skins.ISkinProvider provider)
            : base(owner, provider)
        {
        }

        public CustomFormPainter(frmMain owner, DevExpress.LookAndFeel.UserLookAndFeel provider, HorzAlignment captionAlignment)
            : base(owner, provider)
        {
            CaptionAlignment = captionAlignment;
        }

        private HorzAlignment _CaptionAlignment = HorzAlignment.Default;

        public HorzAlignment CaptionAlignment
        {
            get
            {
                return _CaptionAlignment;
            }
            set
            {
                _CaptionAlignment = value;
            }
        }

        protected override void DrawText(DevExpress.Utils.Drawing.GraphicsCache cache)
        {
            string text = Text;
            if (text == null || text.Length == 0 || TextBounds.IsEmpty)
            {
                return;
            }
            AppearanceObject appearance = new AppearanceObject(GetDefaultAppearance());
            appearance.TextOptions.Trimming = Trimming.EllipsisCharacter;
            appearance.TextOptions.HAlignment = CaptionAlignment;
            if (AllowHtmlDraw)
            {
                DrawHtmlText(cache, appearance);
                return;
            }
            Rectangle r = RectangleHelper.GetCenterBounds(TextBounds, new Size(TextBounds.Width, CalcTextHeight(cache.Graphics, appearance)));
            DrawTextShadow(cache, appearance, r);
            cache.DrawString(text, appearance.Font, appearance.GetForeBrush(cache), r, appearance.GetStringFormat());
        }
    }

}