﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GUI
{
    public partial class frmLogin : DevExpress.XtraEditors.XtraForm
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void textBox_TenDangNhap_Enter(object sender, EventArgs e)
        {
            if(textBox_TenDangNhap.Text == "Tên đăng nhập")
            {
                textBox_TenDangNhap.Text = "";
                textBox_TenDangNhap.ForeColor = Color.Black;
            }
        }

        private void textBox_TenDangNhap_Leave(object sender, EventArgs e)
        {
            if (textBox_TenDangNhap.Text == "")
            {
                textBox_TenDangNhap.Text = "Tên đăng nhập";
                textBox_TenDangNhap.ForeColor = Color.DarkGray;
            }
        }

        private void textBox_MatKhau_Enter(object sender, EventArgs e)
        {
            if (textBox_MatKhau.Text == "Mật khẩu")
            {
                textBox_MatKhau.Text = "";
                textBox_MatKhau.ForeColor = Color.Black;
            }
        }

        private void textBox_MatKhau_Leave(object sender, EventArgs e)
        {
            if (textBox_MatKhau.Text == "")
            {
                textBox_MatKhau.Text = "Mật khẩu";
                textBox_MatKhau.ForeColor = Color.DarkGray;
            }
        }

        private void button_Thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CheckTextbox()
        {
            if(textBox_TenDangNhap.Text == "Tên đăng nhập" && textBox_MatKhau.Text == "Mật khẩu")
            {
                label_LoiTenDangNhap.Text = "*Bạn chưa nhập tên đăng nhập";
                label_LoiMatKhau.Text = "*Bạn chưa nhập mật khẩu";
                textBox_TenDangNhap.Focus();
            }else if (textBox_TenDangNhap.Text == "Tên đăng nhập")
            {
                //MessageBox.Show("Bạn chưa nhập tên đăng nhập", "CẢNH BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                label_LoiTenDangNhap.Text = "*Bạn chưa nhập tên đăng nhập";
                label_LoiMatKhau.Text = "";
                textBox_TenDangNhap.Focus();
            } else if (textBox_MatKhau.Text == "Mật khẩu")
            {
                //MessageBox.Show("Bạn chưa nhập mật khẩu", "CẢNH BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                label_LoiMatKhau.Text = "*Bạn chưa nhập mật khẩu";
                label_LoiTenDangNhap.Text = "";
                textBox_MatKhau.Focus();
            }
        }

        private void button_DangNhap_Click(object sender, EventArgs e)
        {
            CheckTextbox();
            frmMain frmMain = (frmMain)base.MdiParent;
            base.Close();
            frmMain.ribbonControl_ButtonFunction.Visible = true;
            Bitmap nullbitmap = new Bitmap(1,1);    //set background null
            frmMain.BackgroundImage = nullbitmap;
        }
    }
}